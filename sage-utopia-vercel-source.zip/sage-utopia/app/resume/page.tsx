import { Download, ExternalLink } from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { PublicHeader } from "@/components/public-header";
import { Card, PageHeader, SectionTitle } from "@/components/ui";
import { profile } from "@/data/sample-data";

export default function ResumePage() {
  return (
    <AppShell>
      <PublicHeader />
      <PageHeader
        eyebrow="在线简历"
        title="一页清晰、可分享的个人简历"
        description="网页版适合快速浏览，PDF 链接适合投递和保存。"
      />

      <div className="grid gap-4 lg:grid-cols-[0.75fr_1.25fr]">
        <Card>
          <SectionTitle title="分享与下载" />
          <div className="space-y-3">
            <a
              href={profile.resumePdfUrl}
              className="flex items-center justify-center gap-2 rounded-full bg-matcha-500 px-5 py-3 text-sm font-semibold text-white"
            >
              <Download size={16} />
              下载 PDF 简历
            </a>
            <a
              href="/resume"
              className="flex items-center justify-center gap-2 rounded-full bg-matcha-100 px-5 py-3 text-sm font-semibold text-matcha-700"
            >
              <ExternalLink size={16} />
              打开分享链接
            </a>
          </div>
        </Card>

        <Card>
          <div className="border-b border-line pb-5">
            <h1 className="text-3xl font-semibold">{profile.name}</h1>
            <p className="mt-3 text-sm leading-7 text-ink/68">{profile.bio}</p>
          </div>
          <div className="mt-5 grid gap-5">
            <section>
              <h2 className="font-semibold">教育经历</h2>
              <ul className="mt-3 space-y-2 text-sm text-ink/68">
                {profile.education.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </section>
            <section>
              <h2 className="font-semibold">核心技能</h2>
              <p className="mt-3 text-sm leading-7 text-ink/68">{profile.skills.join(" / ")}</p>
            </section>
            <section>
              <h2 className="font-semibold">个人方向</h2>
              <p className="mt-3 text-sm leading-7 text-ink/68">{profile.interests.join(" / ")}</p>
            </section>
          </div>
        </Card>
      </div>
    </AppShell>
  );
}
