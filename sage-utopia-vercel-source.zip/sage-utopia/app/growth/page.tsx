import { Search } from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { SageMascot } from "@/components/sage-mascot";
import { Card, PageHeader, SectionTitle, StatCard } from "@/components/ui";
import { growthEntries } from "@/data/sample-data";

export default function GrowthPage() {
  const tags = Array.from(new Set(growthEntries.flatMap((entry) => entry.tags)));

  return (
    <AppShell>
      <PageHeader
        eyebrow="成长记录"
        title="把今天的自己温柔地留下来"
        description="记录心情、收获、挑战和关键词。未来回头看时，你会知道自己一直在前进。"
      />

      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard label="记录数量" value={`${growthEntries.length}`} hint="已经留下的成长片段" />
        <StatCard label="关键词" value={`${tags.length}`} hint="慢慢形成自己的主题" tone="blue" />
        <StatCard label="最近心情" value={growthEntries[0].mood} hint={growthEntries[0].entryDate} tone="peach" />
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-[0.75fr_1.25fr]">
        <div className="space-y-4">
          <SageMascot message="还没有写很多也没关系，从今天开始就好。每一条记录都是未来的线索。" />
          <Card>
            <SectionTitle title="搜索与标签" />
            <div className="flex items-center gap-2 rounded-2xl border border-line bg-white px-4 py-3">
              <Search size={18} className="text-ink/48" />
              <span className="text-sm text-ink/44">搜索成长记录</span>
            </div>
            <div className="mt-4 flex flex-wrap gap-2">
              {tags.map((tag) => (
                <button key={tag} className="rounded-full bg-matcha-100 px-3 py-1 text-xs font-medium text-matcha-700">
                  #{tag}
                </button>
              ))}
            </div>
          </Card>
        </div>

        <Card>
          <SectionTitle title="时间轴" subtitle="日期、心情、今日收获、今日挑战、成长记录" />
          <div className="space-y-4">
            {growthEntries.map((entry) => (
              <article key={entry.id} className="rounded-2xl border border-line/70 bg-white p-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <p className="font-semibold">{entry.entryDate}</p>
                    <p className="mt-1 text-sm text-ink/58">心情：{entry.mood}</p>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {entry.tags.map((tag) => (
                      <span key={tag} className="rounded-full bg-matcha-50 px-3 py-1 text-xs text-matcha-700">
                        #{tag}
                      </span>
                    ))}
                  </div>
                </div>
                <div className="mt-4 grid gap-3 sm:grid-cols-2">
                  <div className="rounded-2xl bg-matcha-50 p-3">
                    <p className="text-xs font-medium text-matcha-700">今日收获</p>
                    <p className="mt-1 text-sm leading-6 text-ink/68">{entry.todayGain}</p>
                  </div>
                  <div className="rounded-2xl bg-[#FFF1E9] p-3">
                    <p className="text-xs font-medium text-ink/70">今日挑战</p>
                    <p className="mt-1 text-sm leading-6 text-ink/68">{entry.todayChallenge}</p>
                  </div>
                </div>
                <p className="mt-4 text-sm leading-7 text-ink/70">{entry.content}</p>
              </article>
            ))}
          </div>
        </Card>
      </div>
    </AppShell>
  );
}
