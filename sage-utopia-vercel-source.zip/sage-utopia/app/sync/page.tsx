import { AppShell } from "@/components/app-shell";
import { MoodleSyncPanel } from "@/components/moodle-sync-panel";
import { Card, PageHeader, SectionTitle } from "@/components/ui";

export default function SyncPage() {
  return (
    <AppShell>
      <PageHeader
        eyebrow="同步中心"
        title="把 Moodle 截止日期带回 Sage Utopia"
        description="用 Moodle 日历订阅链接同步课程事件和作业截止日期，不需要保存 UNSW 密码。"
      />

      <div className="grid gap-4 lg:grid-cols-[0.85fr_1.15fr]">
        <Card>
          <SectionTitle title="推荐连接方式" subtitle="安全、低维护，也最适合长期使用" />
          <ol className="space-y-4 text-sm leading-7 text-ink/70">
            <li className="rounded-2xl bg-matcha-50 p-4">
              1. 打开 Moodle 的日历页面。
            </li>
            <li className="rounded-2xl bg-matcha-50 p-4">
              2. 找到“导出日历”或“获取日历链接”。
            </li>
            <li className="rounded-2xl bg-matcha-50 p-4">
              3. 复制 iCal / calendar URL，再粘贴到右侧。
            </li>
          </ol>
          <p className="mt-4 rounded-2xl bg-[#FFF1E9] p-4 text-sm leading-7 text-ink/66">
            你刚发来的链接是 Moodle 日历页面链接，可以打开查看，但通常不能被系统直接读取。同步需要的是订阅链接，常见格式会包含 export 或 .ics。
          </p>
        </Card>

        <MoodleSyncPanel />
      </div>
    </AppShell>
  );
}
