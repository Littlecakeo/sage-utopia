import { AppShell } from "@/components/app-shell";
import { Card, PageHeader, ProgressBar, SectionTitle, StatCard } from "@/components/ui";
import { expenses } from "@/data/sample-data";
import { budgetUsage, groupExpensesByCategory, monthlyBudget, monthlyExpenseTotal } from "@/lib/metrics";

const categoryTotals = groupExpensesByCategory();

export default function FinancePage() {
  return (
    <AppShell>
      <PageHeader
        eyebrow="财务中心"
        title="让预算变得温柔清楚"
        description="只记录关键分类和金额，用月度视角看见留学生活的消费节奏。"
      />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="本月支出" value={`$${monthlyExpenseTotal.toFixed(0)}`} hint="六月已记录消费" />
        <StatCard label="月度预算" value={`$${monthlyBudget}`} hint="可按生活状态调整" tone="blue" />
        <StatCard label="预算使用" value={`${budgetUsage}%`} hint="目前仍可控" tone="peach" />
        <StatCard label="记录数量" value={`${expenses.length}`} hint="本月支出记录" />
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-[0.85fr_1.15fr]">
        <Card>
          <SectionTitle title="预算分析" subtitle="本月支出 / 月度预算" />
          <p className="text-5xl font-semibold">{budgetUsage}%</p>
          <div className="mt-5">
            <ProgressBar value={budgetUsage} />
          </div>
          <p className="mt-4 text-sm leading-6 text-ink/62">V1 先帮助你看清大方向，不做复杂预测。</p>
        </Card>

        <Card>
          <SectionTitle title="分类统计" subtitle="房租、餐饮、购物、交通、娱乐、学费、旅行" />
          <div className="space-y-4">
            {Object.entries(categoryTotals).map(([category, amount]) => (
              <div key={category}>
                <div className="mb-2 flex justify-between text-sm">
                  <span>{category}</span>
                  <span>${amount.toFixed(0)}</span>
                </div>
                <ProgressBar value={(amount / monthlyExpenseTotal) * 100} />
              </div>
            ))}
          </div>
        </Card>
      </div>

      <Card className="mt-6">
        <SectionTitle title="最近支出" subtitle="金额、日期、分类、备注" />
        <div className="divide-y divide-line/70">
          {expenses.map((expense) => (
            <div key={expense.id} className="grid gap-2 py-4 sm:grid-cols-[1fr_auto]">
              <div>
                <p className="font-medium">{expense.category}</p>
                <p className="mt-1 text-sm text-ink/58">{expense.expenseDate} · {expense.notes}</p>
              </div>
              <p className="text-lg font-semibold">${expense.amount.toFixed(2)}</p>
            </div>
          ))}
        </div>
      </Card>
    </AppShell>
  );
}
