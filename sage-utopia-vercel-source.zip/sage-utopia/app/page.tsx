import { CalendarDays, CheckCircle2, Clock, Sprout } from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { ExternalLinks } from "@/components/external-links";
import { SageMascot } from "@/components/sage-mascot";
import { Card, PageHeader, ProgressBar, QuickButton, SectionTitle, StatCard, StatusPill } from "@/components/ui";
import { assignments, courses, jobApplications } from "@/data/sample-data";
import {
  activeApplications,
  activeAssignments,
  budgetUsage,
  daysUntil,
  graduationProgress,
  latestGrowthEntry,
  monthlyBudget,
  monthlyExpenseTotal,
  remainingUoc
} from "@/lib/metrics";

export default function HomePage() {
  const nextAssignments = [...activeAssignments].sort((a, b) => a.dueDate.localeCompare(b.dueDate));

  return (
    <AppShell>
      <PageHeader
        eyebrow="2026年6月4日，星期四"
        title="今天也在慢慢长大"
        description="这里是你的学习、求职、生活预算和成长记录入口。先看清今天，再照顾未来。"
      />

      <div className="mb-6 grid gap-4 lg:grid-cols-[1.25fr_0.75fr]">
        <Card className="sage-grid bg-white/72">
          <SectionTitle title="快速新增" subtitle="把新的事情轻轻放进系统里" />
          <div className="flex flex-wrap gap-3">
            <QuickButton label="新增作业" />
            <QuickButton label="新增申请" />
            <QuickButton label="新增支出" />
            <QuickButton label="新增记录" />
          </div>
        </Card>
        <SageMascot message="今天也慢慢来，先完成一件小事就很好。你的未来正在被认真整理。" />
      </div>

      <Card className="mb-6">
        <SectionTitle title="UNSW 快捷入口" subtitle="学校官网、Moodle 学习中心和 myUNSW 放在每天最容易找到的位置" />
        <ExternalLinks />
      </Card>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="课程进度" value={`${graduationProgress}%`} hint={`剩余 ${remainingUoc} UOC`} />
        <StatCard label="作业倒计时" value={`${daysUntil(nextAssignments[0].dueDate)} 天`} hint={nextAssignments[0].title} tone="blue" />
        <StatCard label="求职进度" value={`${activeApplications.length} 个`} hint="正在推进的机会" tone="peach" />
        <StatCard label="预算概览" value={`${budgetUsage}%`} hint={`$${monthlyExpenseTotal.toFixed(0)} / $${monthlyBudget}`} />
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <SectionTitle title="今日任务" subtitle="轻量聚焦，不把一天塞满" />
          <div className="space-y-3">
            {nextAssignments.slice(0, 2).map((assignment) => (
              <div key={assignment.id} className="flex items-start gap-3 rounded-2xl bg-matcha-50 p-4">
                <Clock className="mt-0.5 text-matcha-700" size={18} />
                <div className="min-w-0 flex-1">
                  <p className="font-medium">{assignment.title}</p>
                  <p className="mt-1 text-sm text-ink/60">截止日期 {assignment.dueDate}，权重 {assignment.weight}%</p>
                </div>
                <StatusPill>{assignment.status}</StatusPill>
              </div>
            ))}
            <div className="flex items-start gap-3 rounded-2xl bg-[#EEF8F9] p-4">
              <CalendarDays className="mt-0.5 text-ink/70" size={18} />
              <div>
                <p className="font-medium">准备 Canva 面试案例</p>
                <p className="mt-1 text-sm text-ink/60">整理内容运营项目与英文自我介绍。</p>
              </div>
            </div>
          </div>
        </Card>

        <Card>
          <SectionTitle title="本周任务" subtitle="只保留最值得关注的进展" />
          <div className="space-y-4">
            <div>
              <div className="mb-2 flex justify-between text-sm">
                <span>已提交作业</span>
                <span>{assignments.filter((item) => item.status === "已提交").length}/{assignments.length}</span>
              </div>
              <ProgressBar value={33} />
            </div>
            <div>
              <div className="mb-2 flex justify-between text-sm">
                <span>已完成课程</span>
                <span>{courses.filter((item) => item.status === "已完成").length}/{courses.length}</span>
              </div>
              <ProgressBar value={20} />
            </div>
            <div>
              <div className="mb-2 flex justify-between text-sm">
                <span>求职申请</span>
                <span>{jobApplications.filter((item) => item.status !== "收藏").length}/{jobApplications.length}</span>
              </div>
              <ProgressBar value={67} />
            </div>
          </div>
        </Card>
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        <Card>
          <SectionTitle title="课程进度" />
          <p className="text-4xl font-semibold">{graduationProgress}%</p>
          <p className="mt-2 text-sm text-ink/62">已完成 UOC 正在一点点累积。</p>
          <div className="mt-5">
            <ProgressBar value={graduationProgress} />
          </div>
        </Card>
        <Card>
          <SectionTitle title="求职进度" />
          <div className="space-y-3">
            {jobApplications.map((item) => (
              <div key={item.id} className="flex items-center justify-between gap-3 text-sm">
                <span className="truncate">{item.companyName}</span>
                <StatusPill>{item.status}</StatusPill>
              </div>
            ))}
          </div>
        </Card>
        <Card>
          <SectionTitle title="成长数据" />
          <div className="flex items-center gap-3">
            <CheckCircle2 className="text-matcha-700" />
            <p className="text-sm leading-6 text-ink/70">{latestGrowthEntry.todayGain}</p>
          </div>
          <div className="mt-4 flex flex-wrap gap-2">
            {latestGrowthEntry.tags.map((tag) => (
              <span key={tag} className="rounded-full bg-matcha-100 px-3 py-1 text-xs text-matcha-700">
                #{tag}
              </span>
            ))}
          </div>
          <div className="mt-5 flex items-center gap-2 text-sm text-ink/58">
            <Sprout size={16} />
            最近一次记录：{latestGrowthEntry.entryDate}
          </div>
        </Card>
      </div>
    </AppShell>
  );
}
