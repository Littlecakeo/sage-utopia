import { Instagram, Linkedin, Mail, Send } from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { PublicHeader } from "@/components/public-header";
import { Card, PageHeader, SectionTitle } from "@/components/ui";
import { profile } from "@/data/sample-data";

const contacts = [
  { label: "邮箱", value: profile.email, href: `mailto:${profile.email}`, icon: Mail },
  { label: "LinkedIn", value: "个人主页", href: profile.linkedin, icon: Linkedin },
  { label: "Instagram", value: "内容与生活记录", href: profile.instagram, icon: Instagram },
  { label: "小红书", value: "可选分享渠道", href: profile.xiaohongshu, icon: Send }
];

export default function ContactPage() {
  return (
    <AppShell>
      <PublicHeader />
      <PageHeader
        eyebrow="联系方式"
        title="欢迎从这里联系我"
        description="适合实习机会、内容合作、项目交流和职业网络连接。"
      />

      <Card>
        <SectionTitle title="联系渠道" />
        <div className="grid gap-4 sm:grid-cols-2">
          {contacts.map((contact) => {
            const Icon = contact.icon;
            return (
              <a
                key={contact.label}
                href={contact.href}
                className="flex items-center gap-4 rounded-2xl border border-line/70 bg-matcha-50 p-5 transition hover:-translate-y-0.5 hover:bg-white hover:shadow-tiny"
              >
                <span className="flex size-12 items-center justify-center rounded-full bg-white text-matcha-700">
                  <Icon size={20} />
                </span>
                <span>
                  <span className="block font-semibold">{contact.label}</span>
                  <span className="mt-1 block text-sm text-ink/58">{contact.value}</span>
                </span>
              </a>
            );
          })}
        </div>
      </Card>
    </AppShell>
  );
}
