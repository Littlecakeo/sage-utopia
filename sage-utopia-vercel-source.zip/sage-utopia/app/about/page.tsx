import Image from "next/image";
import { AppShell } from "@/components/app-shell";
import { PublicHeader } from "@/components/public-header";
import { Card, PageHeader, SectionTitle } from "@/components/ui";
import { profile } from "@/data/sample-data";

export default function AboutPage() {
  return (
    <AppShell>
      <PublicHeader />
      <PageHeader
        eyebrow="关于我"
        title="用内容、品牌与生活经验，慢慢建立自己的方向"
        description="这里是一个面向实习、合作和未来机会的个人介绍页面。"
      />

      <div className="grid gap-4 lg:grid-cols-[0.85fr_1.15fr]">
        <Card>
          <div className="relative aspect-square overflow-hidden rounded-[22px] bg-matcha-100">
            <Image src={profile.avatarUrl} alt="个人头像" fill className="object-cover" priority />
          </div>
          <p className="mt-5 text-2xl font-semibold">{profile.name}</p>
          <p className="mt-3 text-sm leading-7 text-ink/68">{profile.bio}</p>
        </Card>

        <div className="grid gap-4">
          <Card>
            <SectionTitle title="教育经历" />
            <div className="space-y-3">
              {profile.education.map((item) => (
                <p key={item} className="rounded-2xl bg-matcha-50 p-4 text-sm text-ink/72">
                  {item}
                </p>
              ))}
            </div>
          </Card>
          <Card>
            <SectionTitle title="技能" />
            <div className="flex flex-wrap gap-2">
              {profile.skills.map((skill) => (
                <span key={skill} className="rounded-full bg-matcha-100 px-4 py-2 text-sm font-medium text-matcha-700">
                  {skill}
                </span>
              ))}
            </div>
          </Card>
          <Card>
            <SectionTitle title="兴趣方向" />
            <div className="flex flex-wrap gap-2">
              {profile.interests.map((interest) => (
                <span key={interest} className="rounded-full bg-[#EEF8F9] px-4 py-2 text-sm font-medium text-ink/70">
                  {interest}
                </span>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </AppShell>
  );
}
