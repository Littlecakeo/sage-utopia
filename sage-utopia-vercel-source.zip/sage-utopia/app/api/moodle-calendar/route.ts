import { NextResponse } from "next/server";

type CalendarEvent = {
  title: string;
  date: string;
  source: string;
};

function unfoldIcs(value: string) {
  return value.replace(/\r?\n[ \t]/g, "");
}

function readField(block: string, field: string) {
  const line = block
    .split(/\r?\n/)
    .find((item) => item.startsWith(`${field}:`) || item.startsWith(`${field};`));

  if (!line) {
    return "";
  }

  return line.slice(line.indexOf(":") + 1).replace(/\\,/g, ",").replace(/\\n/g, " ").trim();
}

function formatIcsDate(raw: string) {
  if (!raw) {
    return "未提供日期";
  }

  const compact = raw.replace(/\D/g, "");
  if (compact.length < 8) {
    return raw;
  }

  return `${compact.slice(0, 4)}-${compact.slice(4, 6)}-${compact.slice(6, 8)}`;
}

function parseIcs(content: string): CalendarEvent[] {
  const unfolded = unfoldIcs(content);
  const blocks = unfolded.match(/BEGIN:VEVENT[\s\S]*?END:VEVENT/g) ?? [];

  return blocks.slice(0, 30).map((block) => ({
    title: readField(block, "SUMMARY") || "未命名 Moodle 事件",
    date: formatIcsDate(readField(block, "DTSTART") || readField(block, "DUE")),
    source: "Moodle"
  }));
}

export async function POST(request: Request) {
  const body = (await request.json()) as { url?: string };
  const rawUrl = body.url?.trim();

  if (!rawUrl) {
    return NextResponse.json({ error: "请先粘贴 Moodle 日历订阅链接。" }, { status: 400 });
  }

  let parsedUrl: URL;
  try {
    parsedUrl = new URL(rawUrl);
  } catch {
    return NextResponse.json({ error: "这个链接格式不正确，请重新复制日历订阅链接。" }, { status: 400 });
  }

  const allowedHosts = ["moodle.telt.unsw.edu.au", "www.unsw.edu.au", "unsw.edu.au"];
  if (!allowedHosts.includes(parsedUrl.hostname)) {
    return NextResponse.json({ error: "为了保护隐私，V1 只读取 UNSW / Moodle 相关链接。" }, { status: 400 });
  }

  const response = await fetch(parsedUrl.toString(), {
    headers: { Accept: "text/calendar, text/plain, */*" },
    cache: "no-store"
  });

  if (!response.ok) {
    return NextResponse.json({ error: "无法读取这个链接。请确认它是 Moodle 导出的日历订阅链接。" }, { status: 400 });
  }

  const content = await response.text();
  if (!content.includes("BEGIN:VCALENDAR")) {
    return NextResponse.json(
      {
        error:
          "这个链接看起来是 Moodle 页面链接，不是日历订阅链接。请在 Moodle 日历里找到“导出日历”或“获取日历链接”。"
      },
      { status: 400 }
    );
  }

  return NextResponse.json({ events: parseIcs(content) });
}
