import { CalendarClock } from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { Card, PageHeader, SectionTitle, StatCard, StatusPill } from "@/components/ui";
import { jobApplications } from "@/data/sample-data";
import { groupByStatus, interviewApplications } from "@/lib/metrics";

const groups = groupByStatus(jobApplications);
const statuses = ["收藏", "已申请", "面试中", "已录取", "已拒绝"];

export default function CareerPage() {
  return (
    <AppShell>
      <PageHeader
        eyebrow="求职中心"
        title="把机会整理成清晰的下一步"
        description="追踪收藏、申请、面试和结果，不让任何一个机会散落在聊天记录里。"
      />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="总机会" value={`${jobApplications.length}`} hint="已记录岗位" />
        <StatCard label="已申请" value={`${groups["已申请"]?.length ?? 0}`} hint="等待回复中" tone="blue" />
        <StatCard label="面试中" value={`${interviewApplications.length}`} hint="需要准备材料" tone="peach" />
        <StatCard label="已录取" value={`${groups["已录取"]?.length ?? 0}`} hint="未来会有好消息" />
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-[0.85fr_1.15fr]">
        <Card>
          <SectionTitle title="面试提醒" subtitle="近期需要准备的机会" />
          <div className="space-y-3">
            {interviewApplications.map((item) => (
              <div key={item.id} className="rounded-2xl bg-[#EEF8F9] p-4">
                <div className="flex items-center gap-2 font-semibold">
                  <CalendarClock size={18} />
                  {item.interviewDate}
                </div>
                <p className="mt-2">{item.companyName}</p>
                <p className="mt-1 text-sm text-ink/60">{item.roleName}</p>
              </div>
            ))}
          </div>
        </Card>

        <Card>
          <SectionTitle title="求职列表" subtitle="公司、岗位、地点、申请日期、状态、备注" />
          <div className="space-y-3">
            {jobApplications.map((item) => (
              <article key={item.id} className="rounded-2xl border border-line/70 p-4">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <p className="font-semibold">{item.companyName}</p>
                    <p className="mt-1 text-sm text-ink/64">{item.roleName} · {item.location}</p>
                    <p className="mt-2 text-xs text-ink/48">申请日期 {item.applicationDate}</p>
                  </div>
                  <StatusPill>{item.status}</StatusPill>
                </div>
                <p className="mt-3 text-sm leading-6 text-ink/62">{item.notes}</p>
              </article>
            ))}
          </div>
        </Card>
      </div>

      <Card className="mt-6">
        <SectionTitle title="状态看板" subtitle="轻量进度分析，避免企业后台感" />
        <div className="grid gap-4 md:grid-cols-5">
          {statuses.map((status) => (
            <div key={status} className="rounded-2xl bg-matcha-50 p-4">
              <p className="mb-3 font-semibold">{status}</p>
              <p className="text-3xl font-semibold">{groups[status]?.length ?? 0}</p>
            </div>
          ))}
        </div>
      </Card>
    </AppShell>
  );
}
