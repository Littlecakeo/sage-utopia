import Image from "next/image";
import { ExternalLink } from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { PublicHeader } from "@/components/public-header";
import { Card, PageHeader, SectionTitle } from "@/components/ui";
import { portfolioProjects } from "@/data/sample-data";

export default function PortfolioPage() {
  return (
    <AppShell>
      <PublicHeader />
      <PageHeader
        eyebrow="作品集"
        title="把做过的项目整理成可以被看见的故事"
        description="展示项目名称、简介、图片、链接、负责内容和成果，让个人品牌逐渐清晰。"
      />

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {portfolioProjects.map((project) => (
          <Card key={project.id} className="overflow-hidden p-0">
            <div className="relative aspect-[4/3] overflow-hidden bg-matcha-100">
              <Image src={project.imageUrl} alt={project.title} fill className="object-cover transition duration-500 hover:scale-105" />
            </div>
            <div className="p-5">
              <div className="flex items-start justify-between gap-3">
                <h2 className="text-lg font-semibold">{project.title}</h2>
                {project.isFeatured ? (
                  <span className="rounded-full bg-matcha-100 px-3 py-1 text-xs font-medium text-matcha-700">精选</span>
                ) : null}
              </div>
              <p className="mt-3 text-sm leading-6 text-ink/66">{project.summary}</p>
              <div className="mt-4 space-y-3 rounded-2xl bg-matcha-50 p-4 text-sm text-ink/70">
                <p><span className="font-semibold">负责内容：</span>{project.role}</p>
                <p><span className="font-semibold">成果展示：</span>{project.outcome}</p>
              </div>
              <a href={project.projectUrl} className="mt-4 inline-flex items-center gap-2 text-sm font-semibold text-matcha-700">
                查看项目
                <ExternalLink size={15} />
              </a>
            </div>
          </Card>
        ))}
      </div>
    </AppShell>
  );
}
