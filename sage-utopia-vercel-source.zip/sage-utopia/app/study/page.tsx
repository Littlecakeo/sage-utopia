import { AppShell } from "@/components/app-shell";
import { ExternalLinks } from "@/components/external-links";
import { Card, PageHeader, ProgressBar, SectionTitle, StatCard, StatusPill } from "@/components/ui";
import { assignments, courses, targetUoc } from "@/data/sample-data";
import { completedUoc, daysUntil, getCourseById, groupByStatus, remainingUoc, selectedUoc } from "@/lib/metrics";

const assignmentGroups = groupByStatus(assignments);

export default function StudyPage() {
  return (
    <AppShell>
      <PageHeader
        eyebrow="学习中心"
        title="课程与作业，都有自己的位置"
        description="用最少字段管理 UNSW 课程、UOC、作业截止日期和毕业进度。"
      />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="目标学分" value={`${targetUoc}`} hint="UNSW 毕业规划" />
        <StatCard label="已完成" value={`${completedUoc}`} hint="已经稳稳拿下" tone="blue" />
        <StatCard label="本学期" value={`${selectedUoc}`} hint="正在修读 UOC" tone="peach" />
        <StatCard label="剩余学分" value={`${remainingUoc}`} hint="未来慢慢完成" />
      </div>

      <Card className="mt-6">
        <SectionTitle title="UNSW 学习入口" subtitle="从这里进入 Moodle、myUNSW 和学校官网" />
        <ExternalLinks />
      </Card>

      <div className="mt-6 grid gap-4 lg:grid-cols-[0.9fr_1.1fr]">
        <Card>
          <SectionTitle title="毕业进度" subtitle="已完成 UOC / 目标 UOC" />
          <p className="text-5xl font-semibold">{Math.round((completedUoc / targetUoc) * 100)}%</p>
          <div className="mt-5">
            <ProgressBar value={(completedUoc / targetUoc) * 100} />
          </div>
          <p className="mt-4 text-sm leading-6 text-ink/62">V1 先做轻量计算，不校验复杂专业规则，保持低维护。</p>
        </Card>

        <Card>
          <SectionTitle title="课程管理" subtitle="课程代码、课程名称、UOC、学期、状态" />
          <div className="space-y-3">
            {courses.map((course) => (
              <div key={course.id} className="grid gap-2 rounded-2xl border border-line/70 p-4 sm:grid-cols-[1fr_auto]">
                <div>
                  <p className="font-semibold">{course.courseCode}</p>
                  <p className="mt-1 text-sm text-ink/64">{course.courseName}</p>
                  <p className="mt-2 text-xs text-ink/48">{course.term} · {course.uoc} UOC</p>
                </div>
                <StatusPill>{course.status}</StatusPill>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <Card className="mt-6">
        <SectionTitle title="作业管理" subtitle="列表、日期分组与轻量看板可以从这里延展" />
        <div className="mb-4 flex gap-2">
          {["列表", "日历", "看板"].map((view) => (
            <button key={view} className="rounded-full bg-matcha-100 px-4 py-2 text-sm font-medium text-matcha-700">
              {view}
            </button>
          ))}
        </div>
        <div className="grid gap-4 lg:grid-cols-3">
          {["未开始", "进行中", "已提交"].map((status) => (
            <div key={status} className="rounded-2xl bg-matcha-50 p-4">
              <h3 className="mb-3 font-semibold">{status}</h3>
              <div className="space-y-3">
                {(assignmentGroups[status] ?? []).map((assignment) => (
                  <article key={assignment.id} className="rounded-2xl bg-white p-4 shadow-tiny">
                    <p className="font-medium">{assignment.title}</p>
                    <p className="mt-2 text-sm text-ink/60">{getCourseById(assignment.courseId)?.courseCode}</p>
                    <p className="mt-2 text-xs text-ink/52">
                      {assignment.dueDate} · {assignment.weight}% · 剩余 {Math.max(daysUntil(assignment.dueDate), 0)} 天
                    </p>
                  </article>
                ))}
              </div>
            </div>
          ))}
        </div>
      </Card>
    </AppShell>
  );
}
