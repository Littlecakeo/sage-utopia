import type {
  Assignment,
  Course,
  Expense,
  GrowthEntry,
  JobApplication,
  PortfolioProject,
  Profile
} from "@/types/sage";

export const targetUoc = 144;

export const courses: Course[] = [
  {
    id: "c1",
    courseCode: "COMM1000",
    courseName: "Creating Social Change",
    uoc: 6,
    term: "2026 T1",
    status: "已完成"
  },
  {
    id: "c2",
    courseCode: "ADVT2001",
    courseName: "Advertising Strategy",
    uoc: 6,
    term: "2026 T2",
    status: "已选课"
  },
  {
    id: "c3",
    courseCode: "PRIA3002",
    courseName: "Public Relations Practice",
    uoc: 6,
    term: "2026 T2",
    status: "已选课"
  },
  {
    id: "c4",
    courseCode: "MARK2051",
    courseName: "Consumer Behaviour",
    uoc: 6,
    term: "2026 T3",
    status: "计划修读"
  },
  {
    id: "c5",
    courseCode: "ARTS2095",
    courseName: "Digital Media",
    uoc: 6,
    term: "2026 T3",
    status: "计划修读"
  }
];

export const assignments: Assignment[] = [
  {
    id: "a1",
    title: "品牌传播策略报告",
    courseId: "c2",
    dueDate: "2026-06-12",
    weight: 35,
    status: "进行中",
    notes: "先完成目标受众分析，再整理 campaign insight。"
  },
  {
    id: "a2",
    title: "PR Case Study Presentation",
    courseId: "c3",
    dueDate: "2026-06-18",
    weight: 25,
    status: "未开始",
    notes: "可以选择澳洲本地品牌案例。"
  },
  {
    id: "a3",
    title: "Weekly Reflection",
    courseId: "c3",
    dueDate: "2026-06-06",
    weight: 10,
    status: "已提交",
    notes: "已提交 Moodle。"
  }
];

export const jobApplications: JobApplication[] = [
  {
    id: "j1",
    companyName: "Ogilvy Sydney",
    roleName: "PR Intern",
    location: "Sydney",
    applicationDate: "2026-05-21",
    status: "已申请",
    notes: "需要下周补充作品集链接。"
  },
  {
    id: "j2",
    companyName: "Canva",
    roleName: "Content Marketing Intern",
    location: "Sydney / Remote",
    applicationDate: "2026-05-28",
    status: "面试中",
    interviewDate: "2026-06-10",
    notes: "准备内容运营案例和自我介绍。"
  },
  {
    id: "j3",
    companyName: "The Works",
    roleName: "Social Media Assistant",
    location: "Sydney",
    applicationDate: "2026-06-01",
    status: "收藏",
    notes: "周末整理申请材料。"
  }
];

export const expenses: Expense[] = [
  { id: "e1", category: "房租", amount: 1280, expenseDate: "2026-06-01", notes: "六月房租" },
  { id: "e2", category: "餐饮", amount: 42.5, expenseDate: "2026-06-02", notes: "学校附近午餐和咖啡" },
  { id: "e3", category: "交通", amount: 18, expenseDate: "2026-06-02", notes: "Opal 充值" },
  { id: "e4", category: "购物", amount: 76, expenseDate: "2026-06-03", notes: "课程材料和生活用品" },
  { id: "e5", category: "娱乐", amount: 24, expenseDate: "2026-06-03", notes: "电影票" }
];

export const growthEntries: GrowthEntry[] = [
  {
    id: "g1",
    entryDate: "2026-06-03",
    mood: "平静",
    todayGain: "把作品集项目结构重新整理了一遍。",
    todayChallenge: "申请材料还有一点拖延。",
    content: "今天意识到作品集不是一次做完的东西，而是每周慢慢养出来的。先把《桢游World》放到最前面。",
    tags: ["作品集", "求职", "整理"]
  },
  {
    id: "g2",
    entryDate: "2026-06-02",
    mood: "有点累",
    todayGain: "完成了 PR 课堂反思。",
    todayChallenge: "预算比预期多了一点。",
    content: "需要把外食频率降下来，但也不用太苛刻。留学生活不是只有节省，也要照顾自己的状态。",
    tags: ["学习", "预算", "生活"]
  }
];

export const portfolioProjects: PortfolioProject[] = [
  {
    id: "p1",
    title: "《桢游World——景德镇》",
    summary: "围绕景德镇文化旅行体验制作的内容策划与视觉传播项目。",
    imageUrl: "https://images.unsplash.com/photo-1493106819501-66d381c466f1?auto=format&fit=crop&w=1200&q=80",
    projectUrl: "#",
    role: "内容策划、脚本结构、视觉叙事",
    outcome: "形成可用于个人品牌展示的文化旅行项目案例。",
    isFeatured: true
  },
  {
    id: "p2",
    title: "视频剪辑作品",
    summary: "短视频叙事、节奏剪辑和社交媒体发布素材合集。",
    imageUrl: "https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?auto=format&fit=crop&w=1200&q=80",
    projectUrl: "#",
    role: "剪辑、字幕、封面优化",
    outcome: "建立面向 PR 与内容岗位的视觉表达样本。",
    isFeatured: true
  },
  {
    id: "p3",
    title: "内容运营项目",
    summary: "围绕品牌账号定位、内容栏目和发布节奏进行规划。",
    imageUrl: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=1200&q=80",
    projectUrl: "#",
    role: "账号分析、内容策略、数据复盘",
    outcome: "输出内容日历与运营复盘模板。",
    isFeatured: false
  }
];

export const profile: Profile = {
  name: "Sage Utopia",
  avatarUrl: "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=800&q=80",
  bio: "UNSW Sydney PR & Advertising 学生，关注品牌传播、内容运营、文化旅行叙事与个人品牌建设。正在把学习、作品与未来机会慢慢整理成一个柔软而清晰的成长花园。",
  education: ["UNSW Sydney｜Public Relations & Advertising", "关注方向：品牌策略、内容营销、数字传播"],
  skills: ["内容策划", "社交媒体运营", "视频剪辑", "品牌调研", "中英双语沟通", "项目管理"],
  interests: ["文化旅行", "品牌叙事", "视觉内容", "留学生活", "女性成长"],
  email: "hello@sageutopia.com",
  linkedin: "https://www.linkedin.com/",
  instagram: "https://www.instagram.com/",
  xiaohongshu: "https://www.xiaohongshu.com/",
  resumePdfUrl: "/resume.pdf"
};
