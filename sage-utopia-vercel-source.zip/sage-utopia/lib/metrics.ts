import { assignments, courses, expenses, growthEntries, jobApplications, targetUoc } from "@/data/sample-data";

export function getCourseById(id: string) {
  return courses.find((course) => course.id === id);
}

export const completedUoc = courses
  .filter((course) => course.status === "已完成")
  .reduce((total, course) => total + course.uoc, 0);

export const selectedUoc = courses
  .filter((course) => course.status === "已选课")
  .reduce((total, course) => total + course.uoc, 0);

export const graduationProgress = Math.round((completedUoc / targetUoc) * 100);
export const remainingUoc = targetUoc - completedUoc;

export const monthlyExpenseTotal = expenses.reduce((total, expense) => total + expense.amount, 0);
export const monthlyBudget = 2200;
export const budgetUsage = Math.round((monthlyExpenseTotal / monthlyBudget) * 100);

export const activeAssignments = assignments.filter((assignment) => assignment.status !== "已提交");
export const submittedAssignments = assignments.filter((assignment) => assignment.status === "已提交");
export const interviewApplications = jobApplications.filter((application) => application.status === "面试中");
export const activeApplications = jobApplications.filter((application) => !["已录取", "已拒绝"].includes(application.status));
export const latestGrowthEntry = growthEntries[0];

export function daysUntil(date: string) {
  const today = new Date("2026-06-04T00:00:00");
  const target = new Date(`${date}T00:00:00`);
  return Math.ceil((target.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
}

export function groupByStatus<T extends { status: string }>(items: T[]) {
  return items.reduce<Record<string, T[]>>((groups, item) => {
    groups[item.status] = groups[item.status] ? [...groups[item.status], item] : [item];
    return groups;
  }, {});
}

export function groupExpensesByCategory() {
  return expenses.reduce<Record<string, number>>((groups, expense) => {
    groups[expense.category] = (groups[expense.category] ?? 0) + expense.amount;
    return groups;
  }, {});
}
