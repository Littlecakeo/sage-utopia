export type CourseStatus = "计划修读" | "已选课" | "已完成";
export type AssignmentStatus = "未开始" | "进行中" | "已提交";
export type ApplicationStatus = "收藏" | "已申请" | "面试中" | "已录取" | "已拒绝";
export type ExpenseCategory = "房租" | "餐饮" | "购物" | "交通" | "娱乐" | "学费" | "旅行";

export type Course = {
  id: string;
  courseCode: string;
  courseName: string;
  uoc: number;
  term: string;
  status: CourseStatus;
};

export type Assignment = {
  id: string;
  title: string;
  courseId: string;
  dueDate: string;
  weight: number;
  status: AssignmentStatus;
  notes: string;
};

export type JobApplication = {
  id: string;
  companyName: string;
  roleName: string;
  location: string;
  applicationDate: string;
  status: ApplicationStatus;
  interviewDate?: string;
  notes: string;
};

export type Expense = {
  id: string;
  category: ExpenseCategory;
  amount: number;
  expenseDate: string;
  notes: string;
};

export type GrowthEntry = {
  id: string;
  entryDate: string;
  mood: string;
  todayGain: string;
  todayChallenge: string;
  content: string;
  tags: string[];
};

export type PortfolioProject = {
  id: string;
  title: string;
  summary: string;
  imageUrl: string;
  projectUrl: string;
  role: string;
  outcome: string;
  isFeatured: boolean;
};

export type Profile = {
  name: string;
  avatarUrl: string;
  bio: string;
  education: string[];
  skills: string[];
  interests: string[];
  email: string;
  linkedin: string;
  instagram: string;
  xiaohongshu: string;
  resumePdfUrl: string;
};
