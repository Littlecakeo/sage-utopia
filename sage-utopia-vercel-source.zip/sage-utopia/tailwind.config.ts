import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./data/**/*.{js,ts,jsx,tsx,mdx}"
  ],
  theme: {
    extend: {
      colors: {
        matcha: {
          50: "#F4FAF6",
          100: "#EEF7F1",
          200: "#DDEFE3",
          300: "#A8D5BA",
          500: "#7FB77E",
          700: "#4F7B55"
        },
        mint: "#9ED8DB",
        cream: "#FAF9F6",
        ink: "#2F3A35",
        line: "#E8E1D6",
        peach: "#F4C7AB",
        blush: "#F7D9D4"
      },
      boxShadow: {
        soft: "0 16px 50px rgba(47, 58, 53, 0.08)",
        tiny: "0 8px 22px rgba(47, 58, 53, 0.06)"
      },
      borderRadius: {
        sage: "16px"
      }
    }
  },
  plugins: []
};

export default config;
