import { ExternalLink, GraduationCap, School } from "lucide-react";

const links = [
  {
    label: "UNSW 官网",
    description: "学校官网与最新信息",
    href: "https://www.unsw.edu.au/",
    icon: School
  },
  {
    label: "Moodle 学习中心",
    description: "课程材料、作业与课堂资源",
    href: "https://moodle.telt.unsw.edu.au/login/index.php",
    icon: GraduationCap
  },
  {
    label: "myUNSW",
    description: "选课、学籍与学生服务",
    href: "https://my.unsw.edu.au/student/myunswNotice.html",
    icon: ExternalLink
  }
];

export function ExternalLinks() {
  return (
    <div className="grid gap-3 sm:grid-cols-3">
      {links.map((link) => {
        const Icon = link.icon;
        return (
          <a
            key={link.href}
            href={link.href}
            target="_blank"
            rel="noreferrer"
            className="group flex items-center gap-3 rounded-2xl border border-line/70 bg-white p-4 shadow-tiny transition hover:-translate-y-0.5 hover:bg-matcha-50"
          >
            <span className="flex size-11 shrink-0 items-center justify-center rounded-full bg-matcha-100 text-matcha-700">
              <Icon size={19} />
            </span>
            <span className="min-w-0">
              <span className="flex items-center gap-2 text-sm font-semibold">
                {link.label}
                <ExternalLink size={13} className="opacity-50 transition group-hover:opacity-100" />
              </span>
              <span className="mt-1 block text-xs leading-5 text-ink/56">{link.description}</span>
            </span>
          </a>
        );
      })}
    </div>
  );
}
