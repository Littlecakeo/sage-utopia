import { Leaf, Sparkles } from "lucide-react";

export function SageMascot({ message }: { message: string }) {
  return (
    <div className="flex items-center gap-4 rounded-[24px] border border-matcha-200 bg-white/76 p-4 shadow-tiny">
      <div className="relative flex size-16 shrink-0 items-center justify-center rounded-full bg-matcha-100">
        <div className="absolute -top-1 right-2 rounded-full bg-mint p-1 text-ink">
          <Sparkles size={12} />
        </div>
        <Leaf size={34} className="text-matcha-700" />
      </div>
      <div>
        <p className="text-sm font-semibold text-ink">Sage</p>
        <p className="mt-1 text-sm leading-6 text-ink/66">{message}</p>
      </div>
    </div>
  );
}
