"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import type { ReactNode } from "react";
import {
  BookOpen,
  BriefcaseBusiness,
  CircleDollarSign,
  Cloud,
  Home,
  Leaf,
  PenLine,
  Sparkles,
  UserRound
} from "lucide-react";
import { cn } from "@/lib/cn";

const privateNav = [
  { href: "/", label: "首页", icon: Home },
  { href: "/study", label: "学习中心", icon: BookOpen },
  { href: "/career", label: "求职中心", icon: BriefcaseBusiness },
  { href: "/finance", label: "财务中心", icon: CircleDollarSign },
  { href: "/growth", label: "成长记录", icon: PenLine },
  { href: "/sync", label: "同步中心", icon: Cloud }
];

const publicNav = [
  { href: "/about", label: "关于我" },
  { href: "/resume", label: "在线简历" },
  { href: "/portfolio", label: "作品集" },
  { href: "/contact", label: "联系方式" }
];

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = usePathname();

  return (
    <div className="min-h-screen">
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-72 border-r border-line/80 bg-cream/88 px-5 py-6 backdrop-blur-xl lg:block">
        <Link href="/" className="flex items-center gap-3">
          <div className="flex size-12 items-center justify-center rounded-full bg-matcha-300 text-ink shadow-tiny">
            <Leaf size={24} />
          </div>
          <div>
            <p className="text-lg font-semibold">Sage Utopia</p>
            <p className="text-xs text-ink/60">柔软有序的成长小屋</p>
          </div>
        </Link>

        <nav className="mt-9 space-y-2">
          {privateNav.map((item) => {
            const Icon = item.icon;
            const isActive = pathname === item.href;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex items-center gap-3 rounded-2xl px-4 py-3 text-sm font-medium transition",
                  isActive ? "bg-white text-ink shadow-tiny" : "text-ink/68 hover:bg-white/70 hover:text-ink"
                )}
              >
                <Icon size={18} />
                {item.label}
              </Link>
            );
          })}
        </nav>

        <div className="mt-8 rounded-sage border border-matcha-200 bg-white/70 p-4">
          <div className="flex items-center gap-2 text-sm font-semibold">
            <Sparkles size={16} />
            公开主页
          </div>
          <div className="mt-3 grid grid-cols-2 gap-2">
            {publicNav.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "rounded-xl px-3 py-2 text-xs transition hover:bg-matcha-100",
                  pathname === item.href ? "bg-matcha-100 text-matcha-700" : "text-ink/68"
                )}
              >
                {item.label}
              </Link>
            ))}
          </div>
        </div>
      </aside>

      <header className="sticky top-0 z-20 border-b border-line/70 bg-cream/88 px-4 py-3 backdrop-blur-xl lg:hidden">
        <div className="flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2 font-semibold">
            <span className="flex size-9 items-center justify-center rounded-full bg-matcha-300">
              <Leaf size={19} />
            </span>
            Sage Utopia
          </Link>
          <Link href="/about" className="rounded-full bg-white p-2 shadow-tiny" aria-label="打开公开主页">
            <UserRound size={18} />
          </Link>
        </div>
        <nav className="mt-3 flex gap-2 overflow-x-auto pb-1">
          {privateNav.map((item) => {
            const Icon = item.icon;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex shrink-0 items-center gap-2 rounded-full px-3 py-2 text-xs font-medium",
                  pathname === item.href ? "bg-white text-ink shadow-tiny" : "bg-matcha-100/70 text-ink/68"
                )}
              >
                <Icon size={15} />
                {item.label}
              </Link>
            );
          })}
        </nav>
      </header>

      <main className="lg:pl-72">
        <div className="mx-auto w-full max-w-7xl px-4 py-6 sm:px-6 lg:px-8 lg:py-8">{children}</div>
      </main>
    </div>
  );
}
