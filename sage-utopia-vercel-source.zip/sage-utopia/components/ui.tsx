import { ArrowRight, Plus } from "lucide-react";
import Link from "next/link";
import type { ReactNode } from "react";
import { cn } from "@/lib/cn";

export function PageHeader({
  title,
  eyebrow,
  description,
  action
}: {
  title: string;
  eyebrow?: string;
  description: string;
  action?: { href: string; label: string };
}) {
  return (
    <section className="soft-enter mb-6 flex flex-col justify-between gap-5 rounded-[24px] border border-white/70 bg-white/68 p-5 shadow-soft backdrop-blur sm:p-7 lg:flex-row lg:items-end">
      <div>
        {eyebrow ? <p className="mb-2 text-sm font-medium text-matcha-700">{eyebrow}</p> : null}
        <h1 className="text-3xl font-semibold tracking-normal text-ink sm:text-4xl">{title}</h1>
        <p className="mt-3 max-w-2xl text-sm leading-6 text-ink/68 sm:text-base">{description}</p>
      </div>
      {action ? (
        <Link
          href={action.href}
          className="inline-flex items-center justify-center gap-2 rounded-full bg-matcha-500 px-5 py-3 text-sm font-semibold text-white shadow-tiny transition hover:bg-matcha-700"
        >
          {action.label}
          <ArrowRight size={16} />
        </Link>
      ) : null}
    </section>
  );
}

export function Card({
  children,
  className
}: {
  children: ReactNode;
  className?: string;
}) {
  return <section className={cn("rounded-sage border border-line/70 bg-white p-5 shadow-tiny", className)}>{children}</section>;
}

export function SectionTitle({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <div className="mb-4 flex items-end justify-between gap-3">
      <div>
        <h2 className="text-lg font-semibold text-ink">{title}</h2>
        {subtitle ? <p className="mt-1 text-sm text-ink/58">{subtitle}</p> : null}
      </div>
    </div>
  );
}

export function StatCard({
  label,
  value,
  hint,
  tone = "green"
}: {
  label: string;
  value: string;
  hint: string;
  tone?: "green" | "blue" | "peach" | "plain";
}) {
  const toneClass = {
    green: "bg-matcha-100",
    blue: "bg-[#EEF8F9]",
    peach: "bg-[#FFF1E9]",
    plain: "bg-white"
  }[tone];

  return (
    <Card className={cn("min-h-32", toneClass)}>
      <p className="text-sm text-ink/62">{label}</p>
      <p className="mt-3 text-3xl font-semibold text-ink">{value}</p>
      <p className="mt-2 text-sm text-ink/58">{hint}</p>
    </Card>
  );
}

export function ProgressBar({ value }: { value: number }) {
  return (
    <div className="h-3 overflow-hidden rounded-full bg-matcha-100">
      <div className="h-full rounded-full bg-matcha-500 transition-all" style={{ width: `${Math.min(value, 100)}%` }} />
    </div>
  );
}

export function StatusPill({ children }: { children: ReactNode }) {
  return (
    <span className="inline-flex rounded-full border border-matcha-200 bg-matcha-50 px-3 py-1 text-xs font-medium text-matcha-700">
      {children}
    </span>
  );
}

export function QuickButton({ label }: { label: string }) {
  return (
    <button className="inline-flex items-center justify-center gap-2 rounded-full bg-white px-4 py-3 text-sm font-semibold text-ink shadow-tiny transition hover:-translate-y-0.5 hover:bg-matcha-100">
      <Plus size={16} />
      {label}
    </button>
  );
}
