"use client";

import { useMemo, useState } from "react";
import { CalendarCheck, Loader2 } from "lucide-react";
import { Card, SectionTitle, StatusPill } from "@/components/ui";

type SyncedEvent = {
  title: string;
  date: string;
  source: string;
};

export function MoodleSyncPanel() {
  const [calendarUrl, setCalendarUrl] = useState("");
  const [events, setEvents] = useState<SyncedEvent[]>([]);
  const [message, setMessage] = useState("等待连接 Moodle 日历");
  const [isLoading, setIsLoading] = useState(false);

  const canSync = useMemo(() => calendarUrl.trim().length > 8, [calendarUrl]);

  async function syncCalendar() {
    setIsLoading(true);
    setMessage("正在读取日历链接...");
    setEvents([]);

    try {
      const response = await fetch("/api/moodle-calendar", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: calendarUrl.trim() })
      });
      const data = (await response.json()) as { events?: SyncedEvent[]; error?: string };

      if (!response.ok) {
        setMessage(data.error ?? "同步失败，请检查链接。");
        return;
      }

      setEvents(data.events ?? []);
      setMessage(`已找到 ${(data.events ?? []).length} 个日历事件`);
    } catch {
      setMessage("暂时无法同步。请确认粘贴的是 Moodle 导出的日历订阅链接。");
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <Card>
      <SectionTitle title="连接 Moodle 日历" subtitle="粘贴日历订阅链接后，同步到任务和作业管理" />

      <label className="block text-sm font-semibold text-ink" htmlFor="calendar-url">
        Moodle 日历订阅链接
      </label>
      <textarea
        id="calendar-url"
        value={calendarUrl}
        onChange={(event) => setCalendarUrl(event.target.value)}
        placeholder="粘贴从 Moodle 导出的 iCal / calendar URL"
        className="mt-3 min-h-32 w-full resize-none rounded-2xl border border-line bg-white px-4 py-3 text-sm leading-6 outline-none transition focus:border-matcha-300 focus:ring-4 focus:ring-matcha-100"
      />

      <button
        type="button"
        onClick={syncCalendar}
        disabled={!canSync || isLoading}
        className="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-full bg-matcha-500 px-5 py-3 text-sm font-semibold text-white shadow-tiny transition hover:bg-matcha-700 disabled:cursor-not-allowed disabled:opacity-50"
      >
        {isLoading ? <Loader2 size={17} className="animate-spin" /> : <CalendarCheck size={17} />}
        同步到 Sage Utopia
      </button>

      <p className="mt-4 rounded-2xl bg-matcha-50 p-4 text-sm text-ink/66">{message}</p>

      {events.length > 0 ? (
        <div className="mt-5 space-y-3">
          {events.map((event) => (
            <article key={`${event.title}-${event.date}`} className="rounded-2xl border border-line/70 p-4">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <p className="font-semibold">{event.title}</p>
                  <p className="mt-1 text-sm text-ink/58">{event.date}</p>
                </div>
                <StatusPill>{event.source}</StatusPill>
              </div>
            </article>
          ))}
        </div>
      ) : null}
    </Card>
  );
}
