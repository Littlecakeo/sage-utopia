import Link from "next/link";
import { Leaf } from "lucide-react";

const links = [
  { href: "/about", label: "关于我" },
  { href: "/resume", label: "在线简历" },
  { href: "/portfolio", label: "作品集" },
  { href: "/contact", label: "联系方式" }
];

export function PublicHeader() {
  return (
    <header className="mb-6 flex flex-col gap-4 rounded-[24px] border border-white/70 bg-white/72 p-4 shadow-soft backdrop-blur md:flex-row md:items-center md:justify-between">
      <Link href="/" className="flex items-center gap-3">
        <span className="flex size-11 items-center justify-center rounded-full bg-matcha-300">
          <Leaf size={22} />
        </span>
        <span>
          <span className="block font-semibold">Sage Utopia</span>
          <span className="block text-xs text-ink/58">公开个人主页</span>
        </span>
      </Link>
      <nav className="flex flex-wrap gap-2">
        {links.map((link) => (
          <Link key={link.href} href={link.href} className="rounded-full bg-matcha-100 px-4 py-2 text-sm font-medium text-matcha-700">
            {link.label}
          </Link>
        ))}
      </nav>
    </header>
  );
}
