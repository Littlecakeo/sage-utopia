create type course_status as enum ('计划修读', '已选课', '已完成');
create type assignment_status as enum ('未开始', '进行中', '已提交');
create type application_status as enum ('收藏', '已申请', '面试中', '已录取', '已拒绝');
create type expense_category as enum ('房租', '餐饮', '购物', '交通', '娱乐', '学费', '旅行');

create table courses (
  id uuid primary key default gen_random_uuid(),
  course_code text not null,
  course_name text not null,
  uoc integer not null default 6,
  term text not null,
  status course_status not null default '计划修读',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table assignments (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  course_id uuid references courses(id) on delete set null,
  due_date date not null,
  weight numeric not null default 0,
  status assignment_status not null default '未开始',
  notes text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table job_applications (
  id uuid primary key default gen_random_uuid(),
  company_name text not null,
  role_name text not null,
  location text not null default '',
  application_date date not null,
  status application_status not null default '收藏',
  interview_date date,
  notes text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table expenses (
  id uuid primary key default gen_random_uuid(),
  category expense_category not null,
  amount numeric not null,
  expense_date date not null,
  notes text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table growth_entries (
  id uuid primary key default gen_random_uuid(),
  entry_date date not null,
  mood text not null,
  today_gain text not null default '',
  today_challenge text not null default '',
  content text not null default '',
  tags text[] not null default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table portfolio_projects (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  summary text not null default '',
  image_url text not null default '',
  project_url text not null default '',
  role text not null default '',
  outcome text not null default '',
  sort_order integer not null default 0,
  is_featured boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table profile (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  avatar_url text not null default '',
  bio text not null default '',
  education text[] not null default '{}',
  skills text[] not null default '{}',
  interests text[] not null default '{}',
  email text not null default '',
  linkedin text not null default '',
  instagram text not null default '',
  xiaohongshu text not null default '',
  resume_pdf_url text not null default '',
  updated_at timestamptz not null default now()
);

alter table courses enable row level security;
alter table assignments enable row level security;
alter table job_applications enable row level security;
alter table expenses enable row level security;
alter table growth_entries enable row level security;
alter table portfolio_projects enable row level security;
alter table profile enable row level security;

create policy "public profile read" on profile for select using (true);
create policy "public portfolio read" on portfolio_projects for select using (true);
