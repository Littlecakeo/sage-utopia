# Sage Utopia

A soft and organized digital home for studying, growing, and building a future abroad.

Sage Utopia 是一个面向 UNSW Sydney PR & Advertising 学生的中文个人操作系统，包含私人管理系统和公开个人网站。

## 功能范围

- 首页：今日任务、本周任务、课程进度、作业倒计时、求职进度、预算概览、成长数据
- 学习中心：课程管理、作业管理、毕业进度、剩余 UOC
- 求职中心：申请追踪、面试提醒、状态统计
- 财务中心：预算管理、分类统计、消费趋势入口
- 成长记录：时间轴、搜索、标签分类
- 公开网站：关于我、在线简历、作品集、联系方式

## 技术栈

- Next.js
- TypeScript
- TailwindCSS
- Supabase
- Vercel

## 本地运行

安装依赖后运行：

```bash
npm install
npm run dev
```

如需连接 Supabase，复制 `.env.example` 为 `.env.local`，填入：

```bash
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
```

数据库 schema 在 `supabase/schema.sql`。

## V1 说明

当前版本使用 `data/sample-data.ts` 中的样例数据完成完整界面闭环。真实数据接入时，可以逐步把页面数据源替换为 Supabase 查询。
